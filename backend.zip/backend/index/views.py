#!/usr/bin/env python
#-*- coding:utf8 -*-
from django.http import HttpResponse
import json
from django.shortcuts import render
from django.conf import settings

class ApiReturn(object):
    CODE_OK = 0
    CODE_FAILED = -1
    CODE_LOGIN = -2

    RQUEST_EXCEPTION_MSG = "发生错误，请联系管理员"

    def __init__(self,code=CODE_OK,message="ok",data={}):
        self.__code = code
        self.__message = message
        self.__data = data

    @property
    def code(self):
        return self.__code

    @code.setter
    def code(self, code):
        self.__code = code

    @property
    def message(self):
        return self.__message

    @message.setter
    def message(self, message):
        self.__message = message

    @property
    def count(self):
        return self.__count



    @property
    def data(self):
        return self.__data


    def toJson(self,isUnicode = False):
        retDict = {}
        retDict['code'] = self.code
        retDict['message'] = self.message
        retDict['data'] = self.data
        return json.dumps(retDict)

def pet_introduce(request):
    return render(request,"pet_introduce.html")


def product(request):
    return render(request,"product.html")


def doctor(request):
    return render(request,"doctor.html")


def home(request):
    return render(request,"index.html")





