#!/usr/bin/env python
#-*- coding:utf8 -*-

from django.urls import path

from . import views

urlpatterns = [
    path('', views.home, name='index'),
    path('index.html', views.home, name='index'),

    path('pet_introduce.html', views.pet_introduce, name='pet_introduce'),
    path('product.html', views.product, name='product'),
    path('doctor.html', views.doctor, name='doctor'),

]






